package main;


import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.UIManager;

import model.AFrame;

	public class Start {
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel");
		} catch (Exception a) {
			a.printStackTrace();
		}
		try {
			new AFrame().setVisible(true);;
		} catch (Exception b) {
			// TODO Auto-generated catch block
			b.printStackTrace();
		}
	}
}
