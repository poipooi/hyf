package model;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;


public class CoursePanel extends JPanel {
	private Vector<String> col;
	private Vector<Vector> rowData;
	private JTable jtable;
	private JButton jb1, jb2, jbAddSummit, jbAddCancel;
	private CardLayout card = new CardLayout();
	private JTextField jtfAddCid,jtfAddUser;
	private JPanel jpanelAll = new JPanel(card);
    private JScrollPane jsp;
	private JComboBox jckAddTeacher,jckAddName,jckAddTime,jckAddAddress;
	private JLabel jlCourseCount=new JLabel();
	
	@SuppressWarnings("unchecked")
	public CoursePanel() throws Exception {
		col = new Vector<String>();
	    col.addElement("选课ID");
	    col.addElement("老师");
	    col.addElement("学生");
	    col.addElement("课程");
	    col.addElement("上课时间");
	    col.addElement("上课地点");
	    
	    rowData = new Vector<Vector>();   //声明所有行
		
	    FileReader reader = new FileReader("D://pick.txt");
		BufferedReader br = new BufferedReader(reader);
 
		String eachLine = null;  //定义每一行
		while((eachLine = br.readLine()) != null){  //读文件至末尾  根据给定正则表达式的匹配拆分此字符串。
			String[] temp = eachLine.split(" ");    //每一行里的空格
			Vector<String> row = new Vector<String>();
			for(int i = 0; i < temp.length; i++){
				row.add(temp[i]);
			}
		rowData.add(row);                           //再把每一个row的数据给rowData
		}
		DefaultTableModel dtm = new DefaultTableModel(rowData, col);
		jtable = new JTable();
		jtable.setModel(dtm);
		refresh();
		JScrollPane jsp = new JScrollPane(jtable);
		jsp.setBorder(new TitledBorder("选择课程信息："));
		

		
		//添加
		JPanel jpanelAdd = new JPanel();
		jpanelAdd.setBackground(Color.white);
		jpanelAdd.add(new JLabel("选课ID:"));
		jpanelAdd.add(jtfAddCid = new JTextField(20));
		jpanelAdd.add(new JLabel("老师:"));
		String teacher[] = { "张老师", "王老师" ,"刘老师", "赵老师" ,"钱老师"};
		jckAddTeacher = new JComboBox(teacher);
		jpanelAdd.add(jckAddTeacher);
		jpanelAdd.add(new JLabel("学生:"));
		jpanelAdd.add(jtfAddUser = new JTextField(20));
		jpanelAdd.add(new JLabel("课程:"));
		String name[] = { "高数学分2", "Java学分3" ,"英语学分1", "计算机组成原理学分1" ,"离散数学学分2"};
		jckAddName = new JComboBox(name);
		jpanelAdd.add(jckAddName);
		
		jpanelAdd.add(new JLabel("上课时间:"));
		String time[] = { "周一", "周二" ,"周三", "周四" ,"周五"};
		jckAddTime = new JComboBox(time);
		jpanelAdd.add(jckAddTime);
		
		jpanelAdd.add(new JLabel("上课地点:"));
		String addrss[] = { "一号楼", "二号楼" ,"三号楼"};
		jckAddAddress = new JComboBox(addrss);
		jpanelAdd.add(jckAddAddress);
		
		jpanelAdd.add(jbAddSummit = new JButton("提交"));
		jpanelAdd.add(jbAddCancel = new JButton("取消"));
		jpanelAdd.setLayout(new GridLayout(8, 5, 5, 5));
		jpanelAdd.setBorder(new TitledBorder("选择课程:"));

		//删除
		JPanel jpanelDel = new JPanel();
		jpanelDel.setBackground(Color.white);
		jpanelDel.setLayout(new GridLayout(2, 1));
		jpanelDel.setBorder(new TitledBorder("退选课程:"));

		jpanelAll.setBackground(Color.white);
		jpanelAll.add(jsp, "All");
		jpanelAll.add(jpanelAdd, "Add");
		jpanelAll.add(jpanelDel, "Del");

		JPanel panel = new JPanel();
		panel.setBackground(Color.white);
		panel.add(jb1 = new JButton("选择课程"));
		panel.add(jb2 = new JButton("退课"));
		jb1.setBackground(Color.white);
		jb2.setBackground(Color.white);
		Dimension preferredSize = new Dimension(100,60);
		jb1.setPreferredSize(preferredSize );
		jb2.setPreferredSize(preferredSize );
		panel.setLayout(new GridLayout(1, 9, 5, 5));
		
		this.add(jpanelAll, BorderLayout.CENTER);
		super.add(panel, BorderLayout.SOUTH);
	
		
		//选择课程按钮监听
		jb1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				card.show(jpanelAll, "Add");
				jtfAddCid.requestFocusInWindow();
			}
		});
		//退选课程按钮监听
		jb2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (jtable.getSelectedRows().length == 0) {
					JOptionPane.showMessageDialog(null, "请添加一条选课记录!");
				} else {
					if (JOptionPane.showConfirmDialog(null, "确定删除?") == 0)
						try {
							deleteCourseByTable();
							refresh();
						} catch (Exception a1) {
							a1.printStackTrace();
						}

				}
			}
		});
		
		
		//添加按钮提交时触发
		jbAddSummit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e){
				String cid = jtfAddCid.getText().trim();
				String user = jtfAddUser.getText().trim();
				String name = jckAddName.getSelectedItem().toString();
				String teacher = jckAddTeacher.getSelectedItem().toString();
				String time = jckAddTime.getSelectedItem().toString();
				String address = jckAddAddress.getSelectedItem().toString();
				String strbuffer=cid+" "+teacher+" "+user+" "+name+" "+time+" "+address+"\n";
				
		        try {
		        	FileWriter writer = new FileWriter("D://pick.txt", true);
		        	writer.write(strbuffer);
		        	writer.flush();
		        	writer.close();
		        } catch (IOException a2) {
		            a2.printStackTrace();
		        }
				JOptionPane.showMessageDialog(null, "添加成功!");
				jtfAddCid.setText(null);
				jtfAddUser.setText(null);
				card.first(jpanelAll);
			}
		});
		
		//添加按钮取消时触发
		jbAddCancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				card.first(jpanelAll);
			}
		});
	}
	
	@SuppressWarnings("unchecked")
	private void refresh() {
		try {
			Vector<Vector> rowData2 = new Vector<Vector>();
		    FileReader reader = new FileReader("D://pick.txt");
			BufferedReader br = new BufferedReader(reader);      //缓冲流
	 
			String eachLine = null;                          //定义每一行
			while((eachLine = br.readLine()) != null){
				String[] temp = eachLine.split(" ");
				Vector<String> row = new Vector<String>();
				for(int i = 0; i < temp.length; i++){       //把每一行都加入row再把每一个row的数据给rowData
					row.add(temp[i]);
				}
				rowData2.add(row);
			}
			rowData=rowData2;
			jtable.updateUI();
			
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	private void deleteCourseByTable() throws Exception {
		String values[] = new String[100];
		String courseName[] = new String[100];
		int rows[] = jtable.getSelectedRows();
		for (int i = 0; i < rows.length; i++) {
			values[i] = (String) jtable.getValueAt(rows[i], 0);
			courseName[i] = (String) jtable.getValueAt(rows[i], 1);
			//重新读取文件，遇到以这个开头的不写入新的文件中
			try {
				String readedLine;
				String strbuffer="";
	            BufferedReader br = new BufferedReader(new FileReader("D://pick.txt"));
	            while ((readedLine = br.readLine()) != null) {
	                if (readedLine.startsWith(values[i])) {
	                    continue;
	                }
	                strbuffer=strbuffer+readedLine+"\n";
	            }
	            FileWriter writer = new FileWriter("D://pick.txt");
	            writer.write(strbuffer);
	            writer.flush();
	            writer.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } 
			JOptionPane.showMessageDialog(null, " 【 " + courseName[i] + " 】 删除成功!");
		}
	}
}